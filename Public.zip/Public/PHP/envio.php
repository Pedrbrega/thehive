<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

if(isset($_POST["submit"])) {
    $mail = new PHPMailer(true);



//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

    try {
    
       //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'jkoberma@gmail.com';                     //SMTP username
        $mail->Password   = 'ymzecvfninzundji';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('jkoberma@gmail.com', 'nicolas');
        $mail->addAddress('jkoberma@gmail.com', 'charbas');
        $mail->addAddress('charbeljanosfreitas@gmail.com', 'charbas');
        $mail->addAddress('bernardokfischer@gmail.com', 'bernardo');
        $mail->addAddress('nicholasestevesf@gmail.com', 'nicholas');
        $mail->addReplyTo('jkoberma@gmail.com', 'nixolas');
        $mail->isHTML(true);                                  
        $mail->Subject = 'Equipe Backrooms';
        $body = "Informações formulário <br>

               Nome: " .$_POST['nome']."
               email:" .$_POST['email']. "
               feedback:". $_POST['feedback'];







        $mail->Body    =  $body ;
        $mail->send();
        echo '<script>alert("Email enviado!");</script>';
    } catch (Exception $e) {
      echo "erro ao enviar o email: {$mail->ErrorInfo}";
    }

}else{
    echo "erro ao enviar email, acesso não foi por via formulário";
}